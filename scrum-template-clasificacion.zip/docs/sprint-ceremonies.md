# Sprint Ceremonies — Quick Guide
## Planning
- Select backlog items, clarify scope, set Sprint Goal, estimate.

## Daily (15 min)
- Yesterday/Today/Blockers. Keep board updated.

## Review
- Demo Done items, capture feedback and new items.

## Retro
- What went well? What to improve? One concrete action next sprint.
