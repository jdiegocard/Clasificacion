## Summary
Describe the change and link related issues (e.g., `Fixes #123`).

## Checklist (DoD)
- [ ] Meets all Acceptance Criteria of the linked story
- [ ] Tests added/updated and passing
- [ ] Code reviewed (self)
- [ ] Docs/Changelog updated if needed
- [ ] Ready to deploy / feature flag prepared

## Screenshots / Notes
