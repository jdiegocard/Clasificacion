# Contributing
- Use Issues for work items (User Story / Bug).
- Link PRs to issues using keywords (`Fixes #ID`).
- Follow DoR/DoD from `/docs`.
- Keep branches short-lived; rebase or squash as appropriate.
