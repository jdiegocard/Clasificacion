## Descripción
Explica brevemente los cambios realizados.

## Cambios incluidos
- 

## Checklist
- [ ] El código compila sin errores
- [ ] Pruebas unitarias incluidas / actualizadas
- [ ] Documentación actualizada
- [ ] Cumple criterios de aceptación
